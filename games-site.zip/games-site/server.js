const express = require('express');
const multer = require('multer');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = 'XXTT';
const ADMIN_PASSWORD = 'XXTT.123';
const GAME_CODE = '123';

const dataDir = path.join(__dirname, 'data');
const gamesDir = path.join(dataDir, 'games');
fs.mkdirSync(gamesDir, { recursive: true });

const db = new Database(path.join(dataDir, 'games.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  is_admin INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS games (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  author TEXT NOT NULL,
  folder_name TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
`);

function hash(s) { return crypto.createHash('sha256').update(s).digest('hex'); }
function makeToken() { return crypto.randomBytes(32).toString('hex'); }
function cleanName(s) { return String(s || '').replace(/[^a-zA-Z0-9 _.-]/g, '').trim().slice(0, 60); }

const admin = db.prepare('SELECT id FROM users WHERE username=?').get(ADMIN_USER);
if (!admin) db.prepare('INSERT INTO users(username,password_hash,is_admin) VALUES(?,?,1)').run(ADMIN_USER, hash(ADMIN_PASSWORD));

const upload = multer({
  dest: path.join(dataDir, 'uploads'),
  limits: { files: 200, fileSize: 5 * 1024 * 1024 }
});

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function auth(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Não autenticado.' });
  const row = db.prepare(`SELECT u.id,u.username,u.is_admin FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?`).get(token);
  if (!row) return res.status(401).json({ error: 'Sessão inválida.' });
  req.user = row; req.token = token; next();
}
function adminOnly(req, res, next) { if (!req.user.is_admin) return res.status(403).json({ error: 'Apenas o administrador.' }); next(); }

app.post('/api/register', (req,res)=>{
  const username = cleanName(req.body.username);
  const password = String(req.body.password || '');
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return res.status(400).json({error:'Usuário: 3-20 caracteres, letras, números ou _. '});
  if (password.length < 4) return res.status(400).json({error:'A senha precisa ter pelo menos 4 caracteres.'});
  try {
    db.prepare('INSERT INTO users(username,password_hash) VALUES(?,?)').run(username, hash(password));
    res.json({ok:true});
  } catch { res.status(409).json({error:'Esse usuário já existe.'}); }
});

app.post('/api/login', (req,res)=>{
  const username = cleanName(req.body.username);
  const password = String(req.body.password || '');
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
  if (!u || u.password_hash !== hash(password)) return res.status(401).json({error:'Usuário ou senha incorretos.'});
  const token = makeToken();
  db.prepare('INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)').run(token,u.id,Date.now());
  res.json({token,user:{username:u.username,isAdmin:!!u.is_admin}});
});

app.post('/api/logout', auth, (req,res)=>{ db.prepare('DELETE FROM sessions WHERE token=?').run(req.token); res.json({ok:true}); });
app.get('/api/me', auth, (req,res)=>res.json({username:req.user.username,isAdmin:!!req.user.is_admin}));
app.post('/api/game-code', auth, (req,res)=>res.json({ok:String(req.body.code||'')===GAME_CODE}));

app.get('/api/games', auth, (req,res)=>{
  const games = db.prepare('SELECT id,name,author,created_at FROM games ORDER BY id DESC').all();
  res.json(games);
});

app.get('/api/games/:id', auth, (req,res)=>{
  const g = db.prepare('SELECT * FROM games WHERE id=?').get(Number(req.params.id));
  if (!g) return res.status(404).send('Jogo não encontrado.');
  const indexPath = path.join(gamesDir, String(g.id), 'index.html');
  if (!fs.existsSync(indexPath)) return res.status(404).send('Arquivo do jogo não encontrado.');
  res.sendFile(indexPath);
});

app.post('/api/games', auth, adminOnly, upload.array('files'), (req,res)=>{
  try {
    const name = cleanName(req.body.name);
    if (!name) throw new Error('Dê um nome ao jogo.');
    const files = req.files || [];
    const index = files.find(f => path.basename(f.originalname).toLowerCase() === 'index.html');
    if (!index) throw new Error('A pasta precisa ter um index.html.');

    const result = db.prepare('INSERT INTO games(name,author,folder_name,created_at) VALUES(?,?,?,?)').run(name, req.user.username, name, Date.now());
    const id = result.lastInsertRowid;
    const target = path.join(gamesDir, String(id));
    fs.mkdirSync(target, {recursive:true});

    for (const f of files) {
      const rel = String(f.originalname).replaceAll('\\','/').replace(/^\/+/, '');
      if (rel.includes('..')) continue;
      const dest = path.join(target, rel);
      if (!dest.startsWith(target + path.sep)) continue;
      fs.mkdirSync(path.dirname(dest), {recursive:true});
      fs.renameSync(f.path, dest);
    }
    res.json({ok:true,id});
  } catch(e) {
    for (const f of req.files || []) { try { fs.unlinkSync(f.path); } catch {} }
    res.status(400).json({error:e.message || 'Falha ao publicar.'});
  }
});

app.delete('/api/games/:id', auth, adminOnly, (req,res)=>{
  const id = Number(req.params.id);
  const g = db.prepare('SELECT id FROM games WHERE id=?').get(id);
  if (!g) return res.status(404).json({error:'Jogo não encontrado.'});
  db.prepare('DELETE FROM games WHERE id=?').run(id);
  fs.rmSync(path.join(gamesDir,String(id)), {recursive:true,force:true});
  res.json({ok:true});
});

app.listen(PORT, ()=>console.log(`GAMES rodando em http://localhost:${PORT}`));
